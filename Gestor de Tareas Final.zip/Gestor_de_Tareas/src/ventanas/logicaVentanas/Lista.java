/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ventanas.logicaVentanas;

/**
 *
 * @author Jhoel Rivera
 */
public class Lista {
        Nodo raiz;
        public Lista(){
              raiz = null;
        }
}
